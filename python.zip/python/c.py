# yas=int(input("Yaşınızı girin:"))
# print(yas)

#biraz ileri alıştırma

dyili=int(input("Doğum yılınızı girin:"))
tarih=2025
yas=tarih-dyili
print(yas)
