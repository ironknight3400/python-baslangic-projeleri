# try:
    # hata oluşması muhtemel kod bloğu
# except:
    # hata durumunda yapılacak işlemler

print("Program başladı")
try:
    sayi = int(input("Bir sayı yazınız: "))
    karesi = sayi * sayi
    print("Sayının karesi:", karesi)
except:
    print("Bir hata oluştu !!!")
print("Program sona erdi!")

# birden fazla except bloğu

try:
    sayi1 = int(input("Bölünen: "))
    sayi2 = int(input("Bölen: "))
    sonuc = sayi1 / sayi2
    print("Sonuç:", sonuc)
except ValueError:
    print("Sayı girmediniz!")
except ZeroDivisionError:
    print("Sayıyı 0’a 5bölemezsiniz!")

#Genel yapı şu şekildedir:
# try:
	#	çalıştırılacak	kodlar
# except hatatipi1:
	#		Yapılacak	işlemler
# except hatatipi2:
	#		Yapılacak	işlemler
# except hatatipi3:
	#		Yapılacak	işlemler

# try:
	#	çalıştırılacak	kodlar
# except (hatatipi1, hatatipi2):
	#		Yapılacak	işlemler
# except hatatipi3:
	#		Yapılacak	işlemler

