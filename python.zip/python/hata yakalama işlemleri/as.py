# try:
# sayi1		=	int(input("1.	sayı:	"))
# sayi2		=	int(input("2.	sayı:	"))
# toplam = sayi1 + sayi2
# print("Toplam:", toplam)
# except ValueError as hata:
# print("Sayı	girmediniz!")
# print("Orjinal	hata	mesajı:",	hata)

# finally bloğu 

# try:
  #çalıştırılşacak kodlar
# except 
  #hata oluştuğunda yapılacak işlemler
# finally:
    #hata olsun veya olmasın çalışacak kodlar

# raise ifadesi

# try:
#     sayi1 = int(input("0-10000 arasında bir sayı giriniz: "))
#     if (sayi1 not in range(0, 10001)):
#         raise Exception("Sayı 0-10000 arasında olmalı!")
#     print("Girdiğiniz sayı:", sayi1)
# except Exception as hata:
#     print("Hata:", hata)

# assert ifadesi

# try:
#     cift_sayi	=	int(input("Çift	sayı	giriniz:	"))
#     assert	cift_sayi	%	2	==	0,	"Çift	sayı	girmediniz"
#     print("Girdiğiniz	sayı:",	cift_sayi)
# except AssertionError as hata:
#     print("Hatalı	sayı:",	hata)
# except Exception as hata:
#     print("Bir	hata	oluştu:",	hata)


