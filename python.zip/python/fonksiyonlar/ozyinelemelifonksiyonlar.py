def tumevarim(sayi):
    if sayi == 1:
        return 1
    else:
        return sayi * tumevarim(sayi - 1)
print(tumevarim(5))

def fibonacci(n):
    if n==1:
        return 1
    elif n==2:
        return 1
    else:
        return fibonacci(n-1) + fibonacci(n-2)
for i in range(1,21):
    print(fibonacci(i), end=" ")  
print()

