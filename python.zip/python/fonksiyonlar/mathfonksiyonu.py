from math import sin, cos, sqrt, pow
print(sqrt(4))
print(sin(30))
print(cos(45))
print(pow(3, 2))

import math 
print(math.sqrt(9))
print(math.sin(math.pi/2)) 
print(math.pow(3, 12))
