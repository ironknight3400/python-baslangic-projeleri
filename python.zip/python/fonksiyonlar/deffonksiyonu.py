def selamla():
    print("Merhaba, nasılsın?")
selamla()

def selamla():
    ad =str(input("Adınızı girin: "))

    if ad:
        print("Merhaba, " + ad + "!")
    else:
        print("Merhaba, misafir!")
selamla()


def onakadar_say():
    a = 0 
    while a < 10:
        a+=1
        print(a)
onakadar_say()

def ondefa_yaz():
    for i in range(10):
        print("Merhaba")
ondefa_yaz()

def yildiz_ucgen_ciz():
    for i in range(1,10):
        print("*" * i)
yildiz_ucgen_ciz()

def selamla(ad):
    print("Merhaba, " + ad + "!")
selamla("Ahmet")
selamla("Ayşe")
selamla("Mehmet")

def ulke_yaz(ulke = "Türkiye"):
    print("Ben " + ulke + "'de yaşıyorum.")

ulke_yaz("Almanya")
ulke_yaz("Fransa")
ulke_yaz()
ulke_yaz("İtalya")

def en_kucuk_cocuk(cocuk1, cocuk2, cocuk3):
    print("En küçük çocuk " + cocuk3 + "'dir.")

en_kucuk_cocuk(cocuk1="Ayşe", cocuk2="Fatma", cocuk3="Ali")

def mevsim_yaz(mevsim_dizisi):
    for mevsim in mevsim_dizisi:
        print(mevsim)
mevsimler = ["İlkbahar", "Yaz", "Sonbahar", "Kış"]
mevsim_yaz(mevsimler)

def yildiz_ucgen_ciz(satirSayisi):
    print(str(satirSayisi) + " satırlı yıldız üçgeni çiziliyor:")
    for i in range(1, satirSayisi + 1):
        print("*" * i)
yildiz_ucgen_ciz(5)

def dortgen_alan(kenar1, kenar2):
    alan = kenar1 * kenar2
    print("Dörtgenin alanı: " + str(alan))
dortgen_alan(4, 5)

def cift_mi_tek_mi(sayi):
    if sayi % 2 == 0:
        print(str(sayi) + " çifttir.")
    else:
        print(str(sayi) + " tektir.")
cift_mi_tek_mi(10)
cift_mi_tek_mi(7)

def ortamala_hesapla(sinav1,sinav2,sozlu):
    ortalama = (sinav1 + sinav2 + sozlu) / 3
    return ortalama

def ortalama_hesapla(sinav1, sinav2, sozlu):
    ortalama = (sinav1 + sinav2 + sozlu) / 3
    return ortalama

if ortalama_hesapla(70, 80, 90) >= 50:
    print("Geçtiniz.")
else:
    print("Kaldınız.")

def tam_bolenler_bul(sayi):
    tam_bolenler = []
    for i in range(1, sayi):
        if (sayi % i == 0):
            tam_bolenler.append(i)
    return tam_bolenler
print(tam_bolenler_bul(28))




