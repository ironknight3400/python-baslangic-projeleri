kdvli_fiyat = lambda fiyat: fiyat * 1.18
print(kdvli_fiyat(100))

toplam = lambda a, b: a + b
print(toplam(5, 10))

def carpan(n):
    return lambda x: x * n
ikikat= carpan(2)
uckat = carpan(3)
dortkat = carpan(4)

print(ikikat(5))
print(uckat(5)) 
print(dortkat(5))  


