def toplama(a, b):
    return a + b
def cikarma(a, b):
    return a - b
def carpma(a, b):
    return a * b
def bolme(a, b):
    if b != 0:
        return a / b
    else:
        return "Bir sayı sıfıra bölünemez!"

print("Hesap Makinesi")
print("İşlemler:")
print("1. Toplama")
print("2. Çıkarma")
print("3. Çarpma")
print("4. Bölme")
while True:
   secim = input("Yapmak istediğiniz işlemi seçin (1/2/3/4/ÇIKIŞ İÇİN 'q'): ")
   if secim == "q":
         print("Hesap makinesi kapatılıyor.")
         break
   if secim in ('1', '2', '3', '4'):
       a = float(input("Birinci sayıyı girin: "))
       b = float(input("İkinci sayıyı girin: "))
       if secim == '1':
           print("Sonuç:", toplama(a, b))
       elif secim == '2':
           print("Sonuç:", cikarma(a, b))
       elif secim == '3':
           print("Sonuç:", carpma(a, b))
       elif secim == '4':
           print("Sonuç:", bolme(a, b))
   else:
       print("Geçersiz giriş. Lütfen tekrar deneyin.")
       break

