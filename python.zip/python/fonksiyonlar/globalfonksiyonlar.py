sonuc = 0

def topla(sayi1, sayi2):
    sonuc = sayi1 + sayi2
    print("Toplam:", sonuc)
    return sonuc

topla(5,15)
print("fonksiyon disi sonuc:", sonuc)

sonuc = 10; 
def toplama( sayi1, sayi2 ):

   print("Fonksiyonun içinde toplam: ", sonuc)
   return sonuc 

toplama( 5, 15 )
print("Fonksiyonun	dışında	toplam:	",	sonuc)

sonuc = 0; 
def toplama( sayi1, sayi2 ): 
    global	sonuc	
    sonuc = sayi1 + sayi2 

    print("Fonksiyonun içinde toplam: ", sonuc)
    return sonuc
toplama( 5, 15 ) 
print("Fonksiyonun	dışında	toplam:	",	sonuc)

