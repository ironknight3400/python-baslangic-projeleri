import random

kelime_listesi = ["Türkiye","Gaziantep","Ankara","İstanbul","İzmir","Bursa","Antalya","Adana","Konya","Mersin"]
secilen_kelime = random.choice(kelime_listesi)
tahmin_sayisi=5
harfler = []
x=len(secilen_kelime)
z=list("_"*x)
print("Adam Asmaca Oyununa Hoşgeldiniz!")
print(''.join(z),end="\n")
while tahmin_sayisi>0:
    harf = input("Bir harf giriniz: ")
    if harf in harfler:
        print("Bu harfi zaten girdiniz, başka bir harf deneyiniz.")
        continue

    elif len(harf) > 1:
        print("Lütfen tek bir harf giriniz.")
        continue

    elif harf not in secilen_kelime:
        tahmin_sayisi -= 1
        print(f"Yanlış tahmin! Kalan tahmin hakkınız: {tahmin_sayisi}")

else:
    for i in range(len(secilen_kelime)):
        if harf == secilen_kelime[i]:
            print(f"Tebrikler! '{harf}' harfini doğru tahmin ettiniz.")
            z[i] = harf
            harfler.append(harf)
            print(''.join(z),end="\n")

            cevap = input("Devam etmek istiyor musunuz? (E/H): ")
            if cevap == 'e':
                tahmin=input("Kelimenin tamamını tahmin edin:")
                if tahmin==secilen_kelime:
                    print("Tebrikler! Kelimeyi doğru tahmin ettiniz.")
                    break
            else:
                tahmin_sayisi-=1
                print(f"Yanlış tahmin! Kalan tahmin hakkınız: {tahmin_sayisi}")
                
        if tahmin_sayisi==0:
            print(f"Üzgünüz, tahmin hakkınız kalmadı. Doğru kelime: {secilen_kelime}")
            break            