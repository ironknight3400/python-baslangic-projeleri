ad ="Ad"
soyad ="Soyad"
ara=" "
ad_soyad = ad + ara + soyad
print(ad_soyad)

sehir = "İstanbul"
karakter= sehir[3]
print(sehir[3])
print(sehir[-1])
print(sehir[0:3])
print(sehir[3:])
print(sehir[:3])
print(sehir[:])
print(sehir[::2])
print(sehir[::-1])
print(sehir[1:5:2])
print(len(sehir))
print(sehir.upper())
print(sehir.lower())
print(sehir.title())
print(sehir.strip())
print(sehir.replace("İ","I"))
print(sehir.split("s"))
print(sehir.find("tan"))
print(sehir.startswith("İs"))
print(sehir.endswith("ul"))
print(sehir.isalpha())
print(sehir.isdigit())
print(sehir.count("a"))
print(sehir.index("ta"))
print(sehir.index("s"))
print(sehir.center(20,"*"))
print(sehir.ljust(20,"-"))
print(sehir.rjust(20,"-"))
print(sehir.zfill(20))

print(" ")
print("***************")
print("***************")
print(" ")

sehir1 = "Ankara"
print("sehir değişken boyutu: ", len(sehir1))
boyut = len(sehir1)
son_karakter = sehir1[boyut-1]
print("sehir değişkenin son karakteri: ", son_karakter)
for harf in sehir1:
    print(harf)

print(" ")
print("***************")
print("***************")
print(" ")

#string veriyi parcalama ve bölme
veri="Bilişim Teknolojileri"
print(veri)
print(veri[2:8])
print(veri[2:])
print(veri[5:15])
print(veri[:8])
print(veri[:])
print(veri[::2])
print(veri[::-1])
print(veri[1:10:2])
print(len(veri))
print(veri.upper())
print(veri.lower())
print(veri.title())
print(veri.strip())
print(veri.replace("Bilişim","Bilgisayar"))
print(veri.split(" "))
print(veri.find("Teknoloji"))
print(veri.startswith("Bilişim"))
print(veri.endswith("leri"))
print(veri.isalpha())
print(veri.isdigit())
print(veri.count("i"))
print(veri.index("Teknoloji"))
print(veri.index("i"))
print(veri.center(30,"*"))
print(veri.ljust(30,"-"))
print(veri.rjust(30,"-"))
print(veri.zfill(30))
print(veri.split(" "))

print(" ")
print("***************")
print("***************")
print(" ")

veri = "Bilişim Teknolojileri"
metin = "ilkbahar,yaz,sonbahar,kış"
veri_bolum = veri.split(" ")
metin_bolum = metin.split(",")
metin_bolum_ikieleman = metin.split(",",1)
print(veri_bolum)
print(metin_bolum)
print(metin_bolum_ikieleman)

print(" ")
print("***************")
print("***************")
print(" ")

kelime = "Bilişim"
cumle = "Merhaba Dünya"
print(kelime)
print(kelime.replace("i","o"))
print(cumle)
print(cumle.replace("Merhaba","Selam"))

print(" ")
print("***************")
print("***************")
print(" ")

cumle ="	bilişim	teknolojilerine	giriş	"
print(cumle.strip())
print(cumle.strip(" bil"))
print(cumle.strip("prg"))
cumle2 ='python çok kullanışlı'
print(cumle2.strip("pyt"))

print(" ")
print("***************")
print("***************")
print(" ")

kelime	=	"Gaziantep"
print(".".join(kelime))

print(" ")
print("***************")
print("***************")
print(" ")

kelime = "Bilişim Teknolojileri"
print(kelime.find('m'))
print(kelime.find('no'))
print(kelime.index('i',4))
print(kelime.index('i',1,7))

print(" ")
print("***************")
print("***************")
print(" ")

kelime = "Gaziantep"
print("G" in kelime)
print("k" in kelime)

print(" ")
print("***************")
print("***************")
print(" ")

kelime	="Gaziantep"
print("G" not in kelime)
print("k" not in kelime)

print(" ")
print("***************")
print("***************")
print(" ")

kelime	='Bilişim teknolojileri'
print(kelime.upper())
print(kelime.lower())
print(kelime.capitalize())
print(kelime.title())	
print(kelime.swapcase())

