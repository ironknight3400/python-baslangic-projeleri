from datetime import datetime

an = datetime.now()
print("Şu an", an)

from datetime import date
bugun = date.today()
print("Bugün", bugun)

bugun = datetime.today()

print("Bugün", bugun)
print("Yıl", bugun.year)
print("Ay", bugun.month)
print("Gün", bugun.day)
print("Saat", bugun.hour)
print("Dakika", bugun.minute)
print("Saniye", bugun.second)
print("Mikrosaniye", bugun.microsecond)
print("Haftanın günü", bugun.weekday())
print("Yılın günü", bugun.timetuple().tm_yday)
print("Haftanın günü (Pazar=0)", bugun.isoweekday())
print("Yılın haftası", bugun.isocalendar().week)
print("Zaman damgası", bugun.timestamp())
print("ISO biçimi", bugun.isoformat())
print("Yazdırma biçimi", bugun.strftime("%d/%m/%Y %H:%M:%S"))