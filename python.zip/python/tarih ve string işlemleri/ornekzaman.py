from datetime import datetime

bugun = datetime.today()
print("Bugünün tarihi", bugun)
yil = int(input("Yıl giriniz: "))
ay = int(input("Ay giriniz: "))
gun = int(input("Gün giriniz: "))
dogum = datetime(yil, ay, gun)
fark = bugun - dogum
print("Doğum tarihinizden bugüne kadar geçen gün sayısı:", fark.days)

import datetime

bugun = datetime.datetime.today()
fark = datetime.timedelta(days=150)
gelecek = bugun + fark
print("150 gün sonra tarih:", gelecek)
print("Biçimlendirilmiş Tarih:", gelecek.strftime('%c'))

an = datetime.datetime.now()
print("Şu anki saat:", an.strftime('%X'))
print("Şu anki tarih:", an.strftime('%x'))
print("Yılın günü:", an.strftime('%j'))
print("Haftanın günü:", an.strftime('%A'))
print("Ayın günü:", an.strftime('%d'))