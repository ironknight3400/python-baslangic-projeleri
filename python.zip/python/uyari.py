sayi1=(input("Birinci sayı:"))
sayi2=(input("İkinci sayı:"))
toplam=sayi1+sayi2
print(toplam)


#burada hata şu; eğer int kullanmazsak sayıları alır ve yanyana birleştirir
#1.yöntem

# sayi1=int(input("Birinci sayı:"))
# sayi2=int(input("İkinci sayı:"))
# toplam=sayi1+sayi2
# print(toplam)

#2.yöntem

# sayi1=(input("Birinci sayı:"))
# sayi2=(input("İkinci sayı:"))
# toplam=int(sayi1)+int(sayi2)
# print(toplam)
