#ornek
yas=int(input("Yaşınızı giriniz: "))
if yas>=18:
   print("Ehliyet alabilirsiniz.")
else:
   print("Ehliyet alamazsınız.")

#ornek2
girilen_sayi=int(input("Bir sayı giriniz: "))
if girilen_sayi%2==0:
    print("Girilen sayı çifttir.")
else:
    print("Girilen sayı tektir.")

#ornek3
cikis_birimleri=["yazıcı","hoparlör","monitör"]
if "yazıcı" in cikis_birimleri:
    print("Eleman çıkış birimleri arasında bulunmaktadır.")
else:
    print("Eleman çıkış birimleri arasında bulunmamaktadır.")   

#ornek4
yabanci_dil=input("Yabancı dil biliyor musunuz? (Evet/Hayır): ") 
ofis_programlari=input("Ofis programlarını biliyor musunuz? (Evet/Hayır): ")

if yabanci_dil=="Evet" and ofis_programlari=="Evet":
    print("İş başvurunuz kabul edilmiştir.")
else:
    print("İş başvurunuz reddedilmiştir.")

#ornek5
ad_soyad=input("Adınızı ve soyadınızı giriniz: ")
yas=int(input("Yaşınızı giriniz: "))
yabanci_dil=input("Bildiğiniz yabancı dil:")
if ((yabanci_dil=="İngilizce" or yabanci_dil=="Almanca") and yas>=18):
    print("Sayın",ad_soyad,"iş başvurunuz kabul edilmiştir.")
else:
    print("Sayın",ad_soyad,"iş başvurunuz reddedilmiştir.")


