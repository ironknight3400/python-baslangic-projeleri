#ornek
sayi=int(input("Bir sayi giriniz: "))
if sayi>0:
    print("Sayi pozitiftir.")
elif sayi<0:
    print("Sayi negatiftir.")
else:
    print("Sayi sifirdir.")

#ornek2
sayi1=int(input("Birinci sayiyi giriniz: "))
sayi2=int(input("Ikinci sayiyi giriniz: "))
islem=input("Yapmak istediginiz islemi giriniz (+, -, *, /): ")
if islem=="+":
    print("Toplam:", sayi1+sayi2)
elif islem=="-":
    print("Fark:", sayi1-sayi2)
elif islem=="*":
    print("Carpim:", sayi1*sayi2)
elif islem=="/":
    if sayi2!=0:
        print("Bolum:", sayi1/sayi2)
    else:
        print("Bir sayi 0'a bolunemez.")
else:
    print("Gecersiz islem.")

#ornek3
dogum_yili=int(input("Dogum yilinizi giriniz: "))
yas=2024-dogum_yili
if yas<0:
    print("Gecersiz dogum yili.")
elif yas<18:
    print("Henuz reşit degilsiniz.")
elif yas<65:
    print("Yetiskinsiniz.")
else:
    print("Emeklisiniz.")

#ornek4.içiçe if-elif-else
yas=int(input("Yasinizi giriniz: "))
if yas<40:
    mezuniyet=input("Mezuniyet durumunuzu giriniz (lise, onlisans, lisans, yukseklisans): ")
    surucu=input("Surucu belgeniz var mi? (evet, hayir): ")
    if mezuniyet in ["lise", "onlisans", "lisans", "yukseklisans"] and surucu=="evet":
        print("İşe alındınız.")
    else:
        print("İş başvurunuz kabul edilmedi.")

else:
    print("Kriterlere uymuyorsunuz.")
