sayilar={1,2,3,4,5}
print(sayilar)

sayilar={1,2,3,4,5}
print(6 in sayilar)

#add
sayilar={1,2,3,4,5}
sayilar.add(6)
print(sayilar)

#update
sayilar={1,2,3,4,5}
sayilar.update([6,7,8])
print(sayilar)

#remove
sayilar={1,2,3,4,5}
sayilar.remove(5)
print(sayilar)

#discard
sayilar={1,2,3,4,5}
sayilar.discard(5)
print(sayilar)
