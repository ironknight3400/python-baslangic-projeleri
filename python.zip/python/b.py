print(1>2)
print(2==2)
print(2<-5)