asal_sayilar=[2, 3, 5, 7, 11, 13, 17, 19, 23]
print(asal_sayilar[1:4])

#indeksi 1 olan elemandan başlayarak indeksi 4 olan elemana (4 dâhil değil) 

asal_sayilar=[2, 3, 5, 7, 11, 13, 17, 19, 23]
print(asal_sayilar[5:])

# indeksi 5 olan elemandan başlayarak son elemana kadar

asal_sayilar=[2, 3, 5, 7, 11, 13, 17, 19, 23]
print(asal_sayilar[:5])

# indeksi 0 (sıfır) olan elemandan başlayarak 5e kadar

asal_sayilar=[2, 3, 5, 7, 11, 13, 17, 19, 23]
print(asal_sayilar[0:6:2])

#0dan 6ya kadar ikişer artarak yazar

asal_sayilar=[2, 3, 5, 7, 11, 13, 17, 19, 23]
print(asal_sayilar[::2])

#0dan sona kadar ikişer atlayarak yazar