sehirler=["Ankara", "Bursa", "Çanakkale", "Denizli", "Eskişehir"]
print(sehirler[2])
