import requests

icerik = requests.get('https://www.w3schools.com/xml/note.xml')
print(icerik.text)