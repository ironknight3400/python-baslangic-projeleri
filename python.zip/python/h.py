# ornek=['Y','A','N','I','T']
# print(ornek)
# ornek[0]='K'
# print(ornek)

#modifiye

ornek=['Y','A','N','I','T']
print(ornek)
ornek[0]=input(str("Başharfi değiş:"))
print(ornek)