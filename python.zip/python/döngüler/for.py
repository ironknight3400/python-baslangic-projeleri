for sayilar in range(10):
    print(sayilar)

for sayilar in range(5, 15):
    print(sayilar)

for sayilar in range(0, 20, 2):
    print(sayilar)

for sayilar in range(10, 0, -1):
    print(sayilar)

for sayilar in range(10):
        print(sayilar)
else:
        print("Döngü bitti")

toplam = 0
for sayilar in range(1, 11):
     toplam =toplam + sayilar
print("Toplam:", toplam)

#in kullanımı

meyveler = ["elma", "muz", "çilek"]
for meyve in meyveler:
    print(meyve)

sayilar = [1, 2, 3, 4, 5]
for sayi in sayilar:
    if sayi % 3 == 0:
         print(sayi)

alan_adi="bilişim  "
toplam=0
for karakter in alan_adi:
    if karakter=="i":
        toplam=toplam+1
print("i harfi sayısı:",toplam)

