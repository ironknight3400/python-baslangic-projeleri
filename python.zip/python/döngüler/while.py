i=0
while (i<5):
    print("kodlama")
    i=i+1

i=0
while (i<10):
    print(i)
    i=i+2
    print("while döngüsü bitti")

i=15
while(i<20):
    print(i)
    i=i-1

while True:
    print("sonsuz döngü")

i=1
sonuc=1
faktöriyel=int(input("faktöriyelini almak istediğiniz sayıyı giriniz:"))
while(i<=faktöriyel):
    sonuc=sonuc*i
    i=i+1
print("faktöriyel:",sonuc)

toplam=0
sayi=1
while(sayi!=0):
    sayi=int(input("sayı giriniz:"))
    toplam=toplam+sayi
print("toplam:", toplam)

for i in range(0,5):
    for j in range(0,5):
        print([i,j])

i=1
while True:
    if(i==5):
        print("döngüden çıkılıyor")
        break
    print(i)
    i=i+1

sayi=int(input("sayı giriniz:"))
for i in range(1, 10):
    if(i==sayi):
        print(i)
        break
        print("döngü bitti")
        
metin="Ankara"
for i in metin:
    if(i=="r"):
        break
    print(i)

sayilar=[1,3,5,7,9]
for i in sayilar:
    print(i)
    if(i==5):
        print(i,"sayısına ulaşıldı")
        break   

import random
while True:
    sayi=random.randint(1,10)
    print("Rastgele sayı:", sayi)
    if sayi%2==0:
        print("Çift sayıya ulaşıldı, döngü sonlandırılıyor.")
        break

i=0
while(i<10):
    i=i+1
    if(i==5):
        continue
    print(i)

while True:
    sifre =input ("şifre giriniz:")
    if len(sifre)<8:
        print("şifre en az 8 karakter olmalı")
        continue
    else:
        print("şifre oluşturuldu")
        break
print("şifrenizi while döngüsü ile oluşturduk")

sayilar=[1,3,5,7,9]
for i in sayilar:
    if sayi%2==0:
        continue
    print(i)



    