sozluk={"Mesleğiniz":"Öğrenci","Alanınız":"Bilişim","Yaşadığınız Yer":"Kocaeli"}
print(sozluk)

