donanim={"Türü":"RAM","Tipi":"DDR5","Kapasite":"16GB"}
print(donanim["Türü"])

#değişme
donanim={"Türü":"RAM","Tipi":"DDR5","Kapasite":"16GB"}
donanim["Kapasite"]="8GB"
print(donanim)

#in kullanımı
donanim={"Türü":"RAM","Tipi":"DDR5","Kapasite":"16GB"}
print("Türü"in donanim)

#len kullanımı
donanim={"Türü":"RAM","Tipi":"DDR5","Kapasite":"16GB"}
print(len(donanim))

#key-value eklenmesi
donanim={"Türü": "RAM","Tipi":"DDR4","Kapasitesi":"8GB"}
donanim["Hızı"]="2400MHz"
print(donanim)

#pop
donanim={"Türü":"RAM","Tipi":"DDR4","Kapasite":"8GB"}
donanim.pop("Kapasite")
print(donanim)

#del
#donanim={"Türü":"RAM","Tipi":"DDR4","Kapasite":"8GB"}
#del donanim
#print(donanim)
#burada hata kodu çıkarır çünkü del ile sözlük tamamen silinmiştir

#clear
donanim={"Türü":"RAM","Tipi":"DDR4","Kapasite":"8GB"}
donanim.clear()
print(donanim)

#copy
donanim={"Türü":"RAM","Tipi":"DDR4","Kapasite":"8GB"}
yeni_donanim=donanim.copy()
print(yeni_donanim)

#birdenfazlasözlük
donanim1={"Türü":"RAM","Tipi":"DDR4","Kapasite":"8GB"}
donanim2={"Türü":"SSD","Tipi":"NVMe","Kapasite":"500GB"}
donanim3={"Türü":"Ekran Kartı","Tipi":"RTX 3060","Kapasite":"12GB"}
donanimlarim={"donanim1":donanim1,"donanim2":donanim2,"donanim3":donanim3}
print(donanimlarim)




