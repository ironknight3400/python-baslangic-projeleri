liste=["Muz",61,0.9]
print(liste)