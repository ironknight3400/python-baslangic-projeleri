donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
donanim.clear()
print(donanim)