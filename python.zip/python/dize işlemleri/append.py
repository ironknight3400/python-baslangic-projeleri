donanim=["yazıcı","klavye","işlemci","bellek","sabit disk"]
print(donanim)

donanim.append("bellek")
print(donanim)