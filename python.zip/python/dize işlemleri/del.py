donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
del donanim[3]
print(donanim)