donanim=["yazıcı","yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
say=donanim.count("yazıcı")
print(say)