sayi=[20,40,60,80]
print(len(sayi))

#dizinin eleman sayısını yazar

print(type(sayi))

#sayi iteminin classını söyler 
