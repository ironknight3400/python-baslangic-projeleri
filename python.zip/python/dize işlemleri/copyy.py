donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
yeni_donanim=donanim.copy()
print(yeni_donanim)