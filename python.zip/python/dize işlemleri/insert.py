donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
donanim.insert(2,"tarayıcı")
print(donanim)

#insert ile listenin sayılı elemanını değişiyoruz