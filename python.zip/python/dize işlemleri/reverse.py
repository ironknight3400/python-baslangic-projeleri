donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
donanim.reverse()
print(donanim)