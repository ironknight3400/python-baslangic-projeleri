donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
donanim.pop(2)
print(donanim)

#index belirttiğimiz için o sayılı item silindi
#eğer belirtmezseydik son item silinirdi
