renkler=["Mavi","Yeşil","Kırmızı","Kahverengi","Mor"]
print("Mavi" in renkler)

#elemanın dizide olup olmadığını söyler
