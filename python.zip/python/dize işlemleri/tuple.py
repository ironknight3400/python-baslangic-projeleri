birimler=("bit","inç","byte","hertz","piksel")
print(birimler)

#tuple elemanlarına ulaşma
birimler=("bit","inç","byte","hertz","piksel")
print(birimler[3])

birimler=("bit","inç","byte","hertz","piksel")
print(birimler[-2])

#index aralıklarına göre
birimler=("bit","inç","byte","hertz","piksel")
print(birimler[1:3])

#eleman değişme 
birimler=("bit","inç","byte","hertz","piksel")
birimler_liste=list(birimler)
birimler_liste[2]="mega byte"
print(birimler_liste)

#eleman olup olmadığını sorma
birimler=("bit","inç","byte","hertz","piksel")
print("bit" in birimler)

#tuple uzunluğunu bulma
birimler=("bit","inç","byte","hertz","piksel")
print(len(birimler))

#tuple eleman sayısını bulma
birimler=("bit","inç","byte","hertz","piksel")
say=birimler.count("piksel")
print(say)

#tuple eleman index bulma
birimler=("bit","inç","byte","hertz","piksel")
print(birimler.index("byte"))

#tuple birleştirme
birimler=("bit","inç","byte","hertz","piksel")
degerler=(8,256,1025)
birlestir=birimler+degerler
print(birlestir)