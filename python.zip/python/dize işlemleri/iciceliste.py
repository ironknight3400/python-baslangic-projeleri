bellekler=["RAM","ROM"]
ekran_kartlari=["Paylaşımlı","Paylaşımsız"]
sabit_diskler=["SSD"]
birimler=bellekler,ekran_kartlari,sabit_diskler
print(birimler)

#varyasyonlar

bellekler=["RAM","ROM"]
ekran_kartlari=["Paylaşımlı","Paylaşımsız"]
sabit_diskler=["SSD"]
birimler=bellekler,ekran_kartlari,sabit_diskler
print(birimler[0][1])
#indexi 0 olan bellekler listesinin indexi 1 olan elemanı yazıldı

bellekler=["RAM","ROM"]
ekran_kartlari=["Paylaşımlı","Paylaşımsız"]
sabit_diskler=["SSD"]
birimler=bellekler,ekran_kartlari,sabit_diskler
print(birimler[0][1], birimler[2][0])
