donanim=["yazıcı","klavye","işlemci","bellek","sabit disk"]
yazilim=["işletim sistemi","web tarayıcı"]
donanim.extend(yazilim)
print(donanim)

#böylede kullanılabilir
donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
yazilim=["işletim sistemi", "web tarayıcı"]
print(donanim+yazilim)