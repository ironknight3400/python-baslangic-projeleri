donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
donanim.remove("işlemci")
print(donanim)

#alternatif

donanim=["yazıcı", "klavye", "işlemci", "bellek", "sabit disk"]
donanim.remove(donanim[1])
print(donanim)

